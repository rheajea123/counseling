<?php
// Enable error reporting for debugging (remove this in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Database connection parameters
$host = 'localhost'; // or your host
$db = 'otps_db'; // your database name
$user = 'root'; // your database username
$pass = ''; // your database password
$charset = 'utf8mb4';

// Set up the DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Options for the PDO connection
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Handle any connection errors
    throw new \PDOException($e->getMessage(), (int) $e->getCode());
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare your SQL query to fetch data
    $sql = "SELECT * FROM anecdotal_records WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(1, $id, PDO::PARAM_INT);
    $stmt->execute();
    $data = $stmt->fetch();

    echo json_encode($data);
} else {
    echo json_encode(["error" => "No ID provided"]);
}
?>