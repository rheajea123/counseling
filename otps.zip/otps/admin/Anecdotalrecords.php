<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Page Title</title>
  <link rel="stylesheet" href="style_anecdotal.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <style>
    .delete-container {
      text-align: right;
      margin-top: 10px;
      margin-right: 20px;
    }
  </style>
</head>

<body>
  <div id="currentDate"
    style="font-size: 14px; color: rgb(119, 119, 119); padding: 0; margin: 0; text-align: right; margin-top: 10px;">
  </div>

  <!-- Modal for Viewing Student Details -->
  <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewModalLabel">Student Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!-- Dynamic content loaded here -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal for Editing Student Details -->
  <div class="modal fade" id="editModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Student</h5>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form id="editForm" class="row g-4">
            <input type="hidden" id="edit_id" name="id">
            <!-- Similar fields as your Add New Student form, but with 'edit_' prefix -->
            <!-- Form fields here -->
            <div class="col-12">
              <button type="submit" class="btn btn-primary">Update</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Students List Table -->
  <div class="search-container" style="margin-top: 100px; margin-bottom: 10px;">
    <input type="text" id="searchInput" class="form-control" placeholder="Search for names.."
      style="width: 40%; display: inline-block;">
  </div>
  <div class="col-md-12" style="margin-top: 10px;">
    <div class="panel panel-default" style="background: white;">
      <div class="panel-heading">
        <h3 class="panel-title">Students List</h3>
      </div>
      <div class="table-responsive" style="overflow-x: auto;">
        <table id="students" class="table table-bordered table-condensed">
          <thead>
            <tr id="heads">
              <th><input type="checkbox" id="selectAll" /> Select All</th>
              <th style="padding: 10px; min-width: 1x; text-align: center">Id</th>
              <th style="padding: 10px; min-width: 115px; text-align: center">Name of Students</th>
              <th style="padding: 10px; min-width: 115px; text-align: center">Age</th>
              <th style="padding: 10px; min-width: 115px; text-align: center">Year & Course</th>
              <th style="padding: 10px; min-width: 115px; text-align: center">Gender</th>
              <th style="padding: 10px; min-width: 115px; text-align: center">Action</th>
            </tr>
            </tr>
          </thead>
          <tbody>
            <?php
            $host = 'localhost';
            $db = 'otps_db';
            $user = 'root';
            $pass = '';
            $charset = 'utf8mb4';

            $connection = new mysqli($host, $user, $pass, $db);

            if ($connection->connect_error) {
              die("Connection failed: " . $connection->connect_error);
            }
            $sql = "SELECT * FROM anecdotal_records";
            $result = $connection->query($sql);

            if (!$result) {
              die("Invalid query: " . $connection->error);
            }

            while ($row = $result->fetch_assoc()) {

              echo "
          <tr>
          <td><input type='checkbox' class='rowCheckbox' data-id='{$row['id']}'></td>
          <td>{$row['id']}</td>
          <td>{$row['name_of_students']}</td>
          <td>{$row['age']}</td>
          <td>{$row['year_course']}</td>
          <td>{$row['gender']}</td>
          <td>
        
          <a class='btn btn-primary btn-sm view-user' data-id='{$row['id']}' data-toggle='modal' data-target='#viewModal'>View</a>
          <a class='btn btn-danger btn-sm delete-user' data-id='{$row['id']}'>Delete</a>

        </td>
        </tr>
    ";

            }

            ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="delete-container">
      <button id="deleteSelected" class="btn btn-danger">Delete Selected</button>
    </div>
  </div>

  <script>
    $('#editForm').on('submit', function (e) {
      e.preventDefault();
      var formData = $(this).serialize();

      $.ajax({
        url: 'edit_anecdotal.php',
        type: 'POST',
        data: formData,
        dataType: 'json', // Expecting a JSON response
        success: function (response) {
          if (response.success) {
            // Handle success
          } else {
            // Handle failure
          }
        },
        error: function (xhr, status, error) {
          // Handle AJAX error
        }
      });
    });

    $(document).on('click', '.delete-user', function () {
      var userId = $(this).data('id');
      var row = $(this).closest('tr'); // Get the closest table row

      Swal.fire({
        title: 'Are you sure?',
        text: 'You will not be able to recover this user!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, keep it'
      }).then((result) => {
        if (result.isConfirmed) {
          // AJAX request to server-side script
          $.ajax({
            url: 'delete_anecdotal.php', // Update this URL to the correct path
            type: 'POST',
            data: { id: userId },
            dataType: 'json', // Expect a JSON response
            success: function (response) {
              if (response.success) {
                row.remove(); // Remove the row from the table
                Swal.fire('Deleted!', 'The user has been deleted.', 'success');
              } else {
                Swal.fire('Error', response.message || 'There was a problem deleting the user.', 'error');
              }
            },
            error: function (xhr, status, error) {
              console.error('AJAX Error:', xhr, status, error);
              Swal.fire('Error', 'Failed to delete the user. ' + error, 'error');
            }
          });
        }
      });
    });

    $(document).on('click', '.view-user', function () {
      var userId = $(this).data('id'); // Fetch the ID from the button's data-id attribute

      // AJAX request to fetch user data
      $.ajax({
        url: 'view_anecdotal.php', // Make sure this script returns the HTML content for the student
        type: 'GET',
        data: { id: userId },
        success: function (response) {
          $('#viewModal .modal-body').html(response); // Load the response into the modal body
          $('#viewModal').modal('show'); // Show the modal
        },
        error: function () {
          Swal.fire('Error', 'There was a problem fetching the user details.', 'error');
        }
      });
    });
    $(document).ready(function () {
      // Search functionality
      $("#searchInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#students tbody tr").filter(function () {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
      });

      // Select all checkboxes
      $("#selectAll").click(function () {
        $('input:checkbox').not(this).prop('checked', this.checked);
      });

      // Delete selected functionality
      $("#deleteSelected").click(function () {
        var selectedIds = $('.rowCheckbox:checked').map(function () {
          return $(this).data('id');
        }).get();

        if (selectedIds.length === 0) {
          Swal.fire('Error', 'No students selected.', 'error');
          return;
        }

        Swal.fire({
          title: 'Are you sure?',
          text: 'You will not be able to recover these records!',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete them!',
          cancelButtonText: 'No, keep them'
        }).then((result) => {
          if (result.isConfirmed) {
            $.ajax({
              url: 'delete_batch_anecdotal.php', // Server-side script to delete records
              type: 'POST',
              data: { ids: selectedIds },
              dataType: 'json',
              success: function (response) {
                if (response.success) {
                  // Remove the rows from the table
                  $('.rowCheckbox:checked').closest('tr').remove();
                  Swal.fire('Deleted!', 'Selected students have been deleted.', 'success');
                } else {
                  Swal.fire('Error', response.message || 'There was a problem deleting the records.', 'error');
                }
              },
              error: function (xhr, status, error) {
                console.error('AJAX Error:', status, error);
                Swal.fire('Error', 'Failed to delete the records. ' + error, 'error');
              }
            });
          }
        });
      });


      // Existing script...
    });


    // Existing script...


    $(document).ready(function () {
      // Function to display current date
      function displayDate() {
        var currentDate = new Date().toLocaleDateString();
        $("#currentDate").text(currentDate);
      }

      // Call the function on page load
      displayDate();
    });


  </script>
</body>

</html>