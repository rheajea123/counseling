<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Records</title>
    <link rel="stylesheet" href="path/to/bootstrap.css"> <!-- Ensure you link to your Bootstrap CSS here -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="//path/to/jquery.js"></script> <!-- Ensure you link to your jQuery here -->
    <style>
        .readonly-div {
            background-color: #e9ecef;
            border-radius: 0.25rem;
            padding: 0.375rem 0.75rem;
            border: 1px solid #ced4da;
            min-height: 38px;
            white-space: pre-wrap;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-control {
            border-radius: 0;
            border: none;
            border-bottom: 1px solid black;
        }

        .delete-container {
            text-align: right;
            margin-top: 10px;
            margin-right: 20px;
        }
    </style>
</head>

<body>

    <div class="container">
        <div id="currentDate" class="text-right" style="margin-top: 10px;"></div>
    </div>

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <!-- Modal Content here -->
            </div>
        </div>
    </div>

    <div class="container">
        <div class="search-container" style="margin-top: 100px;">
            <input type="text" id="searchInput" class="form-control" placeholder="Search for names.."
                style="width: 40%; display: inline-block;">
        </div>

        <div class="table-responsive" style="overflow-x: auto;">
            <table id="students" class="table table-bordered table-condensed">
                <thead>
                    <tr id="heads">
                        <th style="text-align: center"><input type="checkbox" id="selectAll" /> Select All</th>
                        <th style="text-align: center">Id</th>
                        <th style="text-align: center">Name</th>
                        <th style="text-align: center">Date</th>
                        <th style="text-align: center">Year & Course</th>
                        <th style="text-align: center">Interview Type</th>
                        <th style="text-align: center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $host = 'localhost';
                    $db = 'otps_db';
                    $user = 'root';
                    $pass = '';
                    $charset = 'utf8mb4';

                    $connection = new mysqli($host, $user, $pass, $db);

                    if ($connection->connect_error) {
                        die("Connection failed: " . $connection->connect_error);
                    }
                    $sql = "SELECT * FROM interview_responses";
                    $result = $connection->query($sql);

                    if (!$result) {
                        die("Invalid query: " . $connection->error);
                    }

                    while ($row = $result->fetch_assoc()) {

                        echo "
                  <tr>
                  <td><input type='checkbox' class='rowCheckbox' data-id='{$row['id']}'></td>
                  <td>{$row['id']}</td>
                  <td>{$row['name']}</td>
                  <td>{$row['date']}</td>
                  <td>{$row['year_course']}</td>
                  <td>{$row['interview_type']}</td>
                  <td>
                  
                      <a class='btn btn-primary btn-sm view-user' data-id='{$row['id']}' data-toggle='modal' data-target='#viewModal'>View</a>
                      <a class='btn btn-danger btn-sm delete-user' data-id='{$row['id']}'>Delete</a>
                  </td>
                  </tr>
              ";

                    }

                    ?>

                </tbody>
            </table>
        </div>
        <div class="delete-container">
            <button id="deleteSelected" class="btn btn-danger">Delete Selected</button>
        </div>
    </div>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>

        $(document).on('click', '.delete-user', function () {
            var userId = $(this).data('id');
            var row = $(this).closest('tr'); // Get the closest table row to this delete button

            Swal.fire({
                title: 'Are you sure?',
                text: 'You will not be able to recover this record!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, keep it'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete_interview.php',
                        type: 'POST',
                        data: { id: userId },
                        success: function (response) {
                            // Assuming your PHP script returns a JSON object with a success property
                            var res = JSON.parse(response);
                            if (res.success) {
                                // If the delete was successful, remove the row from the table
                                row.fadeOut(400, function () {
                                    row.remove();
                                });

                                Swal.fire('Deleted!', 'Your file has been deleted.', 'success');
                            } else {
                                // If the delete was not successful, show an error message
                                Swal.fire('Error', 'The record could not be deleted.', 'error');
                            }
                        },
                        error: function (xhr, status, error) {
                            Swal.fire('Error', 'An error occurred while deleting the record: ' + error, 'error');
                        }
                    });
                }
            });
        });



        $(document).on('click', '.view-user', function () {
            var userId = $(this).data('id'); // Fetch the ID from the button's data-id attribute

            // AJAX request to fetch user data
            $.ajax({
                url: 'view_interview.php', // Make sure this script returns the HTML content for the student
                type: 'GET',
                data: { id: userId },
                success: function (response) {
                    $('#viewModal .modal-body').html(response); // Load the response into the modal body
                    $('#viewModal').modal('show'); // Show the modal
                },
                error: function () {
                    Swal.fire('Error', 'There was a problem fetching the user details.', 'error');
                }
            });
        });

        $(document).on('click', '.edit-user', function () {
            var student_id = $(this).data('id'); // Assuming your edit button has a data-id attribute with the student's ID
            $('#editstudent_id').val(student_id); // Set the student ID to the hidden field, ensuring ID casing matches

            // Populate other fields as necessary
            // Show the modal
            $('#editModal').modal('show');
        });


        $(document).ready(function () {
            // Attach the form submission event listener to the correct form ID
            $('#editStudentForm').on('submit', function (e) {
                e.preventDefault(); // Prevent the default form submission
                var formData = $(this).serialize(); // Serialize the form data

                $.ajax({
                    url: 'edit_interview.php', // Correct URL to the server-side script
                    type: 'POST',
                    data: formData,
                    success: function (response) {
                        // Assuming the response is already a JSON object
                        if (response.success) {
                            Swal.fire('Success', response.message, 'success').then(function () {
                                // Optionally refresh the page or close the modal and update the UI
                                $('#editModal').modal('hide');
                                // Refresh the page or dynamically update your table/list here
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire('Error', 'An error occurred: ' + error, 'error');
                    }
                });
            });
        });

        $(document).ready(function () {
            // Search functionality
            $("#searchInput").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#students tbody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            // Select all checkboxes
            $("#selectAll").click(function () {
                $('input:checkbox').not(this).prop('checked', this.checked);
            });

            // Delete selected functionality
            $("#deleteSelected").click(function () {
                var selectedIds = $('.rowCheckbox:checked').map(function () {
                    return $(this).data('id');
                }).get();

                if (selectedIds.length === 0) {
                    Swal.fire('Error', 'No students selected.', 'error');
                    return;
                }

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You will not be able to recover these records!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete them!',
                    cancelButtonText: 'No, keep them'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'delete_batch_interview.php', // Server-side script to delete records
                            type: 'POST',
                            data: { ids: selectedIds },
                            dataType: 'json',
                            success: function (response) {
                                if (response.success) {
                                    // Remove the rows from the table
                                    $('.rowCheckbox:checked').closest('tr').remove();
                                    Swal.fire('Deleted!', 'Selected students have been deleted.', 'success');
                                } else {
                                    Swal.fire('Error', response.message || 'There was a problem deleting the records.', 'error');
                                }
                            },
                            error: function (xhr, status, error) {
                                console.error('AJAX Error:', status, error);
                                Swal.fire('Error', 'Failed to delete the records. ' + error, 'error');
                            }
                        });
                    }
                });
            });
            $(document).ready(function () {
                // Function to display current date
                function displayDate() {
                    var currentDate = new Date().toLocaleDateString();
                    $("#currentDate").text(currentDate);
                }

                // Call the function on page load
                displayDate();
            });

            // Existing script...
        });



    </script>

</body>

</html>