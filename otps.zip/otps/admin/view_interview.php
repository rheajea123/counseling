<?php
// view_students.php
$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Create a new database connection
$connection = new mysqli($host, $user, $pass, $db);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get the student ID from the GET request
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Prepare the SQL statement
$sql = "SELECT * FROM interview_responses WHERE id = ?";
$stmt = $connection->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch the data and display it
if ($data = $result->fetch_assoc()) {
    echo "<div><strong>Name:</strong> " . htmlspecialchars($data['name']) . "</div>";
    echo "<div><strong>Date:</strong> " . htmlspecialchars($data['date']) . "</div>";
    echo "<div><strong>Year & Course:</strong> " . htmlspecialchars($data['year_course']) . "</div>";
    echo "<div><strong>Interview Type:</strong> " . htmlspecialchars($data['interview_type']) . "</div>";
    echo "<div><strong>As a student, what are your expectations of the school?</strong> " . htmlspecialchars($data['expectations_school']) . "</div>";
    echo "<div><strong>As a student, what are your expectations of your instructors?</strong> " . htmlspecialchars($data['expectations_instructors']) . "</div>";
    echo "<div><strong>As a student, what are your expectations of your peers?</strong> " . htmlspecialchars($data['expectations_peers']) . "</div>";
    echo "<div><strong>Are you aware of the rules and regulations of the school?</strong> " . htmlspecialchars($data['regulations_of_the_school']) . "</div>";
    echo "<div><strong>What will happen if you will violate the set school rules?</strong> " . htmlspecialchars($data['expectations_rules']) . "</div>";
    echo "<div><strong>Are you aware that recording audio and video without consent is prohibited by law?</strong> " . htmlspecialchars($data['expectations_law']) . "</div>";
    echo "<div><strong>What are your insights about people sharing demeaning post on Social Media?</strong> " . htmlspecialchars($data['expectations_social_media']) . "</div>";
    echo "<div><strong>What if you argued with your classmates? Will you post something wrong about them? Why?</strong> " . htmlspecialchars($data['something_wrong_about_them']) . "</div>";
    echo "<div><strong>What will you do if you see a post so demeaning or scandalous and stains the school reputation?</strong> " . htmlspecialchars($data['expectations_schools_reputation']) . "</div>";
    echo "<div><strong>What are your thoughts about bullying incidences in your classroom? In Social Media?</strong> " . htmlspecialchars($data['incidences_in_your_classroom']) . "</div>";
    echo "<div><strong>Do you have an extended family living situation?</strong> " . htmlspecialchars($data['expectations_situation']) . "</div>";
    echo "<div><strong>Who are the people living in your home?</strong> " . htmlspecialchars($data['expectations_home']) . "</div>";
    echo "<div><strong>Describe your relationships with your parents.</strong> " . htmlspecialchars($data['expectations_parents']) . "</div>";
    echo "<div><strong>Describe your relationship with your siblings.</strong> " . htmlspecialchars($data['expectations_siblingsr']) . "</div>";
    echo "<div><strong>Describe your relationship with other people living in your home.</strong> " . htmlspecialchars($data['living_in_your_home']) . "</div>";
    echo "<div><strong> Do you parent's set house rules?</strong> " . htmlspecialchars($data['house_rules']) . "</div>";
    echo "<div><strong>Can you state those rules?</strong> " . htmlspecialchars($data['state_those_rules']) . "</div>";
    echo "<div><strong>What consequences do you face if you do not follow the rules?</strong> " . htmlspecialchars($data['consequences_if_you_not_follow_rules']) . "</div>";
    echo "<div><strong>What are some things you do together as a family?</strong> " . htmlspecialchars($data['together_as_a_family']) . "</div>";
    echo "<div><strong>Where do you spend most of your time?</strong> " . htmlspecialchars($data['expectations_time']) . "</div>";
    echo "<div><strong>What is Guidance Office?</strong> " . htmlspecialchars($data['expectations_guidance_office']) . "</div>";
    echo "<div><strong>What do you think is the role of a Guidance Counselor/Advocate?</strong> " . htmlspecialchars($data['guidance_counselor_advocate']) . "</div>";



} else {
    echo "No data found for this student.";
}

// Close the statement and the connection
$stmt->close();
$connection->close();
?>