<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Appointments List</title>
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 20px;
			background-color: #f4f4f9;
		}

		.container {
			max-width: 1200px;
			margin: 0 auto;
			background: #fff;
			padding: 20px;
			border-radius: 10px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		h1 {
			text-align: center;
			margin-bottom: 20px;
		}

		.search-container {
			margin-bottom: 20px;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.search-container input {
			width: 300px;
			padding: 10px;
		}

		.search-container button {
			padding: 10px 20px;
		}

		table {
			width: 100%;
			border-collapse: collapse;
			margin-top: 20px;
		}

		table th,
		table td {
			padding: 10px;
			text-align: left;
		}

		table th {
			background-color: #f4f4f9;
		}

		.modal .form-label {
			margin-top: 10px;
		}
	</style>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>

<body>
	<?php if ($_settings->chk_flashdata('success')): ?>
		<script>
			alert_toast("<?php echo $_settings->flashdata('success') ?>", 'success')
		</script>
	<?php endif; ?>

	<div class="card card-outline rounded-0 card-navy">
		<div class="card-header">
			<h3 class="card-title">Appointments List</h3>
		</div>
		<div class="card-body">
			<div class="container-fluid">
				<div class="search-container">
					<input type="text" id="searchInput" class="form-control" placeholder="Search for names...">
					<button id="deleteSelected" class="btn btn-danger">Delete Selected</button>
				</div>
				<table class="table table-hover table-striped table-bordered" id="appointmentsTable">
					<colgroup>
						<col width="5%">
						<col width="15%">
						<col width="10%">
						<col width="15%">
						<col width="10%">
						<col width="15%">
						<col width="10%">
						<col width="20%">
						<col width="10%">
						<col width="25%">
					</colgroup>
					<thead>
						<tr>
							<th><input type="checkbox" id="selectAll"> Select All</th>
							<th>Full Name</th>
							<th>Age</th>
							<th>Program</th>
							<th>Gender</th>
							<th>Appointment Date</th>
							<th>Appointment Time</th>
							<th>Reason for Referral</th>
							<th>Reason/Concerns</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php
						require_once ('../config.php');
						$result = $conn->query("SELECT * FROM appointments");
						while ($row = $result->fetch_assoc()) {
							echo "<tr>
								<td><input type='checkbox' class='rowCheckbox' data-id='{$row['id']}'></td>
								<td>{$row['fullname']}</td>
								<td>{$row['age']}</td>
								<td>{$row['course']}</td>
								<td>{$row['gender']}</td>
								<td>{$row['appointment_date']}</td>
								<td>{$row['appointment_time']}</td>
								<td>{$row['reason_for_referral']}</td>
								<td>{$row['reason_concerns']}</td>
								<td align='center'>
									<button type='button' class='btn btn-flat p-1 btn-default btn-sm dropdown-toggle dropdown-icon' data-toggle='dropdown'>
										Action
										<span class='sr-only'>Toggle Dropdown</span>
									</button>
									<div class='dropdown-menu' role='menu'>
										<a class='dropdown-item confirm-btn' data-id='{$row['id']}' href='javascript:void(0)'><span class='fa fa-check text-success'></span> Confirm</a>
										<a class='dropdown-item cancel-btn' data-id='{$row['id']}' href='javascript:void(0)'><span class='fa fa-times text-warning'></span> Cancel</a>
										<a class='dropdown-item delete-btn' data-id='{$row['id']}' href='javascript:void(0)'><span class='fa fa-trash text-danger'></span> Delete</a>
									</div>
								</td>
							</tr>";
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	<script>
		$(document).ready(function () {
			$('#appointmentsTable').DataTable({
				columnDefs: [
					{ orderable: false, targets: [0, 9] }
				],
				order: [1, 'asc']
			});
			$('#appointmentsTable td,#appointmentsTable th').addClass('py-1 px-2 align-middle');

			$('#searchInput').on('keyup', function () {
				var value = $(this).val().toLowerCase();
				$('#appointmentsTable tbody tr').filter(function () {
					$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
				});
			});

			$('#selectAll').click(function () {
				$('input:checkbox').not(this).prop('checked', this.checked);
			});

			$('#deleteSelected').click(function () {
				var selectedIds = $('.rowCheckbox:checked').map(function () {
					return $(this).data('id');
				}).get();

				if (selectedIds.length === 0) {
					Swal.fire('Error', 'No appointments selected.', 'error');
					return;
				}

				Swal.fire({
					title: 'Are you sure?',
					text: 'You will not be able to recover these records!',
					icon: 'warning',
					showCancelButton: true,
					confirmButtonText: 'Yes, delete them!',
					cancelButtonText: 'No, keep them'
				}).then((result) => {
					if (result.isConfirmed) {
						$.ajax({
							url: 'delete_batch.php', // Server-side script to delete records
							type: 'POST',
							data: { ids: selectedIds },
							dataType: 'json',
							success: function (response) {
								if (response.success) {
									// Remove the rows from the table
									$('.rowCheckbox:checked').closest('tr').remove();
									Swal.fire('Deleted!', 'Selected appointments have been deleted.', 'success');
								} else {
									Swal.fire('Error', response.message || 'There was a problem deleting the records.', 'error');
								}
							},
							error: function (xhr, status, error) {
								console.error('AJAX Error:', status, error);
								Swal.fire('Error', 'Failed to delete the records. ' + error, 'error');
							}
						});
					}
				});
			});

			$('.confirm-btn').on('click', function () {
				const id = $(this).data('id');
				$.post('confirm.php', { id: id }, function (response) {
					if (response.status === 'success') {
						Swal.fire('Success', 'Appointment confirmed!', 'success').then(() => {
							location.reload();
						});
					} else {
						Swal.fire('Error', 'Failed to confirm appointment.', 'error');
					}
				}, 'json');
			});

			$('.cancel-btn').on('click', function () {
				const id = $(this).data('id');
				$.post('cancel.php', { id: id }, function (response) {
					if (response.status === 'success') {
						Swal.fire('Success', 'Appointment canceled!', 'success').then(() => {
							location.reload();
						});
					} else {
						Swal.fire('Error', 'Failed to cancel appointment.', 'error');
					}
				}, 'json');
			});

			$('.delete-btn').on('click', function () {
				const id = $(this).data('id');
				$.post('delete.php', { id: id }, function (response) {
					if (response.status === 'success') {
						Swal.fire('Success', 'Appointment deleted!', 'success').then(() => {
							location.reload();
						});
					} else {
						Swal.fire('Error', 'Failed to delete appointment.', 'error');
					}
				}, 'json');
			});
		});
	</script>
</body>

</html>