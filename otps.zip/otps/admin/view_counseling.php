<?php
// view_students.php
$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Create a new database connection
$connection = new mysqli($host, $user, $pass, $db);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get the student ID from the GET request
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Prepare the SQL statement
$sql = "SELECT * FROM counseling_sessions WHERE id = ?";
$stmt = $connection->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch the data and display it
if ($data = $result->fetch_assoc()) {
    echo "<div><strong>Session No.:</strong> " . htmlspecialchars($data['session_no']) . "</div>";
    echo "<div><strong>Session Type:</strong> " . htmlspecialchars($data['session_type']) . "</div>";
    echo "<div><strong>Date:</strong> " . htmlspecialchars($data['date']) . "</div>";
    echo "<div><strong>Name of Student:</strong> " . htmlspecialchars($data['name']) . "</div>";
    echo "<div><strong>Age:</strong> " . htmlspecialchars($data['age']) . "</div>";
    echo "<div><strong>Year & Course:</strong> " . htmlspecialchars($data['year_course']) . "</div>";
    echo "<div><strong>Gender:</strong> " . htmlspecialchars($data['gender']) . "</div>";
    echo "<div><strong>Client/Student Description:</strong> " . htmlspecialchars($data['student_description']) . "</div>";
    echo "<div><strong>Subjective Complaint:</strong> " . htmlspecialchars($data['subjective_complaint']) . "</div>";
    echo "<div><strong>Objective Findings:</strong> " . htmlspecialchars($data['objective_findings']) . "</div>";
    echo "<div><strong>Assessment of Progress:</strong> " . htmlspecialchars($data['assessment_of_progress']) . "</div>";
    echo "<div><strong>Plans for Next Session:</strong> " . htmlspecialchars($data['plans_for_next_session']) . "</div>";
    echo "<div><strong>Other Important Notes:</strong> " . htmlspecialchars($data['other_important_notes']) . "</div>";
} else {
    echo "No data found for this student.";
}

// Close the statement and the connection
$stmt->close();
$connection->close();
?>