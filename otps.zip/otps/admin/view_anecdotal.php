<?php
// view_students.php
$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Create a new database connection
$connection = new mysqli($host, $user, $pass, $db);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get the student ID from the GET request
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Prepare the SQL statement
$sql = "SELECT * FROM anecdotal_records WHERE id = ?";
$stmt = $connection->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch the data and display it
if ($data = $result->fetch_assoc()) {
    echo "<div><strong>name_of_students:</strong> " . htmlspecialchars($data['name_of_students']) . "</div>";
    echo "<div><strong>age:</strong> " . htmlspecialchars($data['age']) . "</div>";
    echo "<div><strong>Year & Course:</strong> " . htmlspecialchars($data['year_course']) . "</div>";
    echo "<div><strong>Gender:</strong> " . htmlspecialchars($data['gender']) . "</div>";
    echo "<div><strong>Father's Name:</strong> " . htmlspecialchars($data['fname']) . "</div>";
    echo "<div><strong>Father Status:</strong> " . htmlspecialchars($data['fatherStatus']) . "</div>";
    echo "<div><strong>Occupation:</strong> " . htmlspecialchars($data['occupation1']) . "</div>";
    echo "<div><strong>Mother's Name:</strong> " . htmlspecialchars($data['mname']) . "</div>";
    echo "<div><strong>Mother Status:</strong> " . htmlspecialchars($data['motherStatus']) . "</div>";
    echo "<div><strong>Occupation:</strong> " . htmlspecialchars($data['occupation2']) . "</div>";
    echo "<div><strong>Guardian(if not living with parents):</strong> " . htmlspecialchars($data['guardian']) . "</div>";
    echo "<div><strong>Occupation:</strong> " . htmlspecialchars($data['occupation3']) . "</div>";
    echo "<div><strong>Permanent Address:</strong> " . htmlspecialchars($data['paddress']) . "</div>";
    echo "<div><strong>Present Address:</strong> " . htmlspecialchars($data['psaddress']) . "</div>";
    echo "<div><strong>Contact Number:</strong> " . htmlspecialchars($data['cnumber']) . "</div>";
    echo "<div><strong>Date & Time/Place of observations:</strong> " . htmlspecialchars($data['dateTime']) . "</div>";
    echo "<div><strong>Observed Behavior(that Need to be Recorded):</strong> " . htmlspecialchars($data['observedBehavior']) . "</div>";
    echo "<div><strong>Comments/Recommendations:</strong> " . htmlspecialchars($data['commentsRecommendations']) . "</div>";
} else {
    echo "No data found for this student.";
}

// Close the statement and the connection
$stmt->close();
$connection->close();
?>