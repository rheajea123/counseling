<?php
// Database configuration
$host = 'localhost';
$dbname = 'otps_db';
$username = 'root';
$password = '';

// Create PDO instance
$dsn = "mysql:host=$host;dbname=$dbname";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);

    // Check if ID is provided
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Prepare DELETE statement
        $sql = "DELETE FROM interview_responses WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        // Execute the statement
        $stmt->execute(['id' => $id]);

        // Check if any row was deleted
        if ($stmt->rowCount()) {
            echo json_encode(['success' => true, 'message' => 'Record deleted successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No record found with the provided ID.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No ID provided.']);
    }
} catch (PDOException $e) {
    error_log("Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
}
?>