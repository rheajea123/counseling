<?php
header('Content-Type: application/json'); // Set proper content type for JSON response

$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data here
    // Example: $sessionNo = filter_input(INPUT_POST, 'session_no', FILTER_SANITIZE_NUMBER_INT);

    try {
        $stmt = $pdo->prepare("INSERT INTO interview_responses (name, date, year_course, interview_type, expectations_school, expectations_instructors, expectations_peers, regulations_of_the_school, expectations_rules, expectations_law, expectations_social_media, something_wrong_about_them, expectations_schools_reputation, incidences_in_your_classroom, expectations_situation, expectations_home, expectations_parents, expectations_siblings, living_in_your_home, house_rules, state_those_rules, consequences_if_you_not_follow_rules, together_as_a_family, expectations_time, expectations_guidance_office, guidance_counselor_advocate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $data = [
            $_POST['name'] ?? null,
            $_POST['date'] ?? null,
            $_POST['year_course'] ?? null,
            $_POST['interview_type'] ?? null,
            $_POST['expectations_school'] ?? null,
            $_POST['expectations_instructors'] ?? null,
            $_POST['expectations_peers'] ?? null,
            $_POST['regulations_of_the_school'] ?? null,
            $_POST['expectations_rules'] ?? null,
            $_POST['expectations_law'] ?? null,
            $_POST['expectations_social_media'] ?? null,
            $_POST['something_wrong_about_them'] ?? null,
            $_POST['expectations_schools_reputation'] ?? null,
            $_POST['incidences_in_your_classroom'] ?? null,
            $_POST['expectations_situation'] ?? null,
            $_POST['expectations_home'] ?? null,
            $_POST['expectations_parents'] ?? null,
            $_POST['expectations_siblings'] ?? null,
            $_POST['living_in_your_home'] ?? null,
            $_POST['house_rules'] ?? null,
            $_POST['state_those_rules'] ?? null,
            $_POST['consequences_if_you_not_follow_rules'] ?? null,
            $_POST['together_as_a_family'] ?? null,
            $_POST['expectations_time'] ?? null,
            $_POST['expectations_guidance_office'] ?? null,
            $_POST['guidance_counselor_advocate'] ?? null,
        ];

        $stmt->execute($data); // Execute the prepared statement with the data array

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Data submitted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Data submission failed']);
        }
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>