<?php
require_once ('../config.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json'); // Ensure JSON response
  $username = $_POST['username'];
  $password = $_POST['password'];

  if (!empty($username) && !empty($password)) {
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
      $user = $result->fetch_assoc();
      if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $username;
        echo json_encode(['status' => 'success']);
      } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid username or password']);
      }
    } else {
      echo json_encode(['status' => 'error', 'message' => 'Invalid username or password']);
    }
  } else {
    echo json_encode(['status' => 'error', 'message' => 'Please enter both username and password']);
  }
  exit;
}
?>
<!DOCTYPE html>
<html lang="en" style="height: auto;">

<head>
  <?php require_once ('inc/header.php'); ?>
  <!-- jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/js/adminlte.min.js"></script>
  <!-- Your custom script -->
  <script src="<?php echo base_url ?>dist/js/script.js"></script>
  <script>
    $(document).ready(function () {
      end_loader();

      $('#login-frm').submit(function (e) {
        e.preventDefault();
        $.ajax({
          url: '',
          type: 'POST',
          data: $(this).serialize(),
          dataType: 'json',
          success: function (response) {
            console.log(response); // Debugging: log response to console
            if (response.status === 'success') {
              window.location.href = 'home.php';
            } else {
              $('#login-error').text(response.message);
            }
          },
          error: function (xhr, status, error) {
            console.error(xhr.responseText); // Debugging: log error to console
            $('#login-error').text('An error occurred. Please try again.');
          }
        });
      });
    });
  </script>
</head>

<body class="hold-transition login-page">
  <script>
    start_loader()
  </script>
  <style>
    body {
      background-image: url("<?php echo validate_image($_settings->info('cover')) ?>");
      background-size: cover;
      background-repeat: no-repeat;
      backdrop-filter: contrast(1);
    }

    img {
      border: solid;
      border-radius: 50%;
      animation: rotation 4s infinite linear;
    }

    @keyframes rotation {
      100% {
        transform: rotateY(360deg);
      }
    }

    #page-title {
      text-shadow: 6px 4px 7px black;
      font-size: 3.5em;
      color: #fff4f4 !important;
      background: #8080801c;
    }
  </style>
  <!--<img src="siitlogo.jpg" style="width: 100px; height: 100px;">-->
  <h1 class="text-center text-white px-4 py-5" id="page-title"><b><?php echo $_settings->info('name') ?></b></h1>
  <div class="login-box">
    <div class="card card-navy my-2">
      <div class="card-body">
        <p class="login-box-msg">Please enter your credentials</p>
        <div id="login-error" class="text-danger"></div>
        <form id="login-frm" action="" method="post">
          <div class="input-group mb-3">
            <input type="text" class="form-control" name="username" autofocus placeholder="Username">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-user"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" class="form-control" name="password" placeholder="Password">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-8">
              <a href="<?php echo base_url ?>">Go to Website</a>
            </div>
            <div class="col-4">
              <button type="submit" class="btn btn-primary btn-block">Sign In</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>

</html>