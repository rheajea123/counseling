<?php
// Database credentials
$host = 'localhost';
$db = 'otps_db'; // Your database name
$user = 'root'; // Your database username
$pass = ''; // Your database password
$charset = 'utf8mb4';

// Create a new PDO instance
try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// Get the ID from POST request
$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

try {
    $stmt = $pdo->prepare("DELETE FROM counseling_sessions WHERE id = :id");
    $stmt->execute(['id' => $id]);

    if ($stmt->rowCount() > 0) {
        // Log and return success response
        error_log("Deleted user with ID: $id");
        echo json_encode(['success' => true, 'message' => 'User deleted successfully.']);
    } else {
        // Log and return failure response if no rows are affected
        error_log("Failed to delete user with ID: $id");
        echo json_encode(['success' => false, 'message' => 'No user found with the specified ID.']);
    }
} catch (\PDOException $e) {
    // Log and return error response
    error_log("Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to delete user.']);
}
?>