<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="counseling.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>
<style>
    .delete-container {
        text-align: right;
        margin-top: 10px;
        margin-right: 20px;
    }
</style>

<body>
    <div class="container">
        <!-- Add this element to display the current date -->
        <div id="currentDate" class="text-right" style="margin-top: 10px;"></div>
    </div>
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Student</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h2>Edit Counseling Session</h2>
                    <form id="editForm" class="row g-4">
                        <input type="hidden" id="edit_student_id" name="id" value="">

                        <div class="form-group">
                            <label for="editsession_no">Session No.:</label>
                            <input type="number" class="form-control" id="editsession_no" name="session_no">
                        </div>

                        <div class="form-group">
                            <label for="session_type">Session Type:</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="editf2f" name="session_type"
                                    value="F2F">
                                <label class="form-check-label" for="editf2f">F2F</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" id="editvirtual" name="session_type"
                                    value="Virtual">
                                <label class="form-check-label" for="editvirtual">Virtual</label>
                            </div>
                        </div>

                        <!-- Include other fields as necessary -->

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- View Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel">Student Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Content will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="search-container" style="margin-top: 100px; margin-bottom: 10px;">
        <input type="text" id="searchInput" class="form-control" placeholder="Search for names.."
            style="width: 40%; display: inline-block;">
    </div>

    <div class="col-md-12" style="margin-top: 10px;"> <!-- Add margin-top for space above the table -->
        <div class="panel panel-default" style="background: white;">
            <div class="panel-heading">
                <h3 class="panel-title">Students List</h3>
            </div>
            <div class="table-responsive" style="overflow-x: auto;">
                <table id="students" class="table table-bordered table-condensed">

                    <thead>
                        <tr id="heads">
                            <th><input type="checkbox" id="selectAll" /> Select All
                            </th>
                            <th style="padding: 10px; min-width: 1x; text-align: center">Id</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Session No.</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Session Type</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Date</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Name of Student</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Age</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Year & Course</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Gender</th>
                            <th style="padding: 10px; min-width: 115px; text-align: center">Action</th>
                        </tr>


                    </thead>
                    <tbody>
                        <?php
                        $host = 'localhost';
                        $db = 'otps_db';
                        $user = 'root';
                        $pass = '';
                        $charset = 'utf8mb4';

                        $connection = new mysqli($host, $user, $pass, $db);

                        if ($connection->connect_error) {
                            die("Connection failed: " . $connection->connect_error);
                        }
                        $sql = "SELECT * FROM counseling_sessions";
                        $result = $connection->query($sql);

                        if (!$result) {
                            die("Invalid query: " . $connection->error);
                        }

                        while ($row = $result->fetch_assoc()) {

                            echo "
                  <tr>
                  <td><input type='checkbox' class='rowCheckbox' data-id='{$row['id']}'></td>
                  <td>{$row['id']}</td>
                  <td>{$row['session_no']}</td>
                  <td>{$row['session_type']}</td>
                  <td>{$row['date']}</td>
                  <td>{$row['name']}</td>
                  <td>{$row['age']}</td>
                  <td>{$row['year_course']}</td>
                  <td>{$row['gender']}</td>
                  
                  <td>
                  
                      <a class='btn btn-primary btn-sm view-user' data-id='{$row['id']}' data-toggle='modal' data-target='#viewModal'>View</a>
                      <a class='btn btn-danger btn-sm delete-user' data-id='{$row['id']}'>Delete</a>
                  </td>
                  </tr>
              ";


                        }

                        ?>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="delete-container">
            <button id="deleteSelected" class="btn btn-danger">Delete Selected</button>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            // Edit button click event
            $(document).on('click', '.edit-user', function () {
                var userId = $(this).data('id'); // Get the ID of the user to be edited

                $.ajax({
                    url: 'fetch_student.php', // This file should return the user's details based on the ID
                    type: 'GET',
                    data: { id: userId },
                    dataType: 'json', // Assuming the response is in JSON format
                    success: function (data) {
                        // Populate the edit form fields with the fetched data
                        $('#editsession_no').val(data.session_no);
                        $('#edit_student_id').val(data.id);
                        if (data.session_type === "F2F") {
                            $('#editModal #f2f').prop('checked', true);
                        } else {
                            $('#editModal #virtual').prop('checked', true);
                        }
                        $('#editdate').val(data.date);
                        $('#editname').val(data.name);
                        $('#editage').val(data.age);


                        // Show the edit modal
                        $('#editModal').modal('show');
                    },
                    error: function (xhr, status, error) {
                        console.error("Error fetching user details:", status, error);
                    }
                });
            });

            // Edit form submission
            $('#editForm').on('submit', function (e) {


                var userId = $(this).data('id'); // Get the ID of the user to be edited

                console.log(userId)
                e.preventDefault(); // Prevent the default form submission
                var formData = $(this).serialize(); // Serialize the form data

                console.log(formData)

                $.ajax({
                    url: 'edit.php', // Make sure this URL points to your PHP script that handles the update.
                    type: 'POST',
                    data: formData,
                    success: function (response) {
                        // Assuming your response is a JSON object with a "success" key
                        if (response.success) {
                            Swal.fire('Success', 'Record updated successfully.', 'success').then(function () {
                                window.location.href = '';
                                // Hide the modal and reload the page or part of it to reflect changes
                                $('#editModal').modal('hide');
                                // Reload the page or fetch the updated list

                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(error)
                        try {
                            var jsonResponse = JSON.parse(xhr.responseText);
                            Swal.fire('Error', 'An error occurred while updating: ' + jsonResponse.message, 'error');
                        } catch (e) {
                            Swal.fire('Error', 'An error occurred while updating: ' + error, 'error');
                        }
                    }


                })
            });
        });

        $(document).on('click', '.delete-user', function () {
            var userId = $(this).data('id');
            var row = $(this).closest('tr'); // Get the closest table row

            Swal.fire({
                title: 'Are you sure?',
                text: 'You will not be able to recover this user!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, keep it'
            }).then((result) => {
                if (result.isConfirmed) {
                    // AJAX request to server-side script
                    $.ajax({
                        url: 'delete_counseling.php', // Update this URL to the correct path
                        type: 'POST',
                        data: { id: userId },
                        dataType: 'json', // Expect a JSON response
                        success: function (response) {
                            if (response.success) {
                                row.remove(); // Remove the row from the table
                                Swal.fire('Deleted!', 'The user has been deleted.', 'success');
                            } else {
                                Swal.fire('Error', response.message || 'There was a problem deleting the user.', 'error');
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error('AJAX Error:', xhr, status, error);
                            Swal.fire('Error', 'Failed to delete the user. ' + error, 'error');
                        }
                    });
                }
            });
        });

        $(document).ready(function () {
            // Search functionality
            $("#searchInput").on("keyup", function () {
                var value = $(this).val().toLowerCase();
                $("#students tbody tr").filter(function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });

            // Select all checkboxes
            $("#selectAll").click(function () {
                $('input:checkbox').not(this).prop('checked', this.checked);
            });

            // Delete selected functionality
            $("#deleteSelected").click(function () {
                var selectedIds = $('.rowCheckbox:checked').map(function () {
                    return $(this).data('id');
                }).get();

                if (selectedIds.length === 0) {
                    Swal.fire('Error', 'No students selected.', 'error');
                    return;
                }

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You will not be able to recover these records!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete them!',
                    cancelButtonText: 'No, keep them'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'delete_batch_counseling.php', // Server-side script to delete records
                            type: 'POST',
                            data: { ids: selectedIds },
                            dataType: 'json',
                            success: function (response) {
                                if (response.success) {
                                    // Remove the rows from the table
                                    $('.rowCheckbox:checked').closest('tr').remove();
                                    Swal.fire('Deleted!', 'Selected students have been deleted.', 'success');
                                } else {
                                    Swal.fire('Error', response.message || 'There was a problem deleting the records.', 'error');
                                }
                            },
                            error: function (xhr, status, error) {
                                console.error('AJAX Error:', status, error);
                                Swal.fire('Error', 'Failed to delete the records. ' + error, 'error');
                            }
                        });
                    }
                });
            });


            // Existing script...
        });



        // View User Event Handler

        $(document).on('click', '.view-user', function () {
            var userId = $(this).data('id');  // Fetch the ID from the button's data-id attribute

            // AJAX request to fetch user data
            $.ajax({
                url: 'view_counseling.php', // Make sure this script returns the HTML content for the student
                type: 'GET',
                data: { id: userId },
                success: function (response) {
                    $('#viewModal .modal-body').html(response);  // Load the response into the modal body
                    $('#viewModal').modal('show');  // Show the modal
                },
                error: function () {
                    Swal.fire('Error', 'There was a problem fetching the user details.', 'error');
                }
            });
        });
        $(document).ready(function () {
            // Function to display current date
            function displayDate() {
                var currentDate = new Date().toLocaleDateString();
                $("#currentDate").text(currentDate);
            }

            // Call the function on page load
            displayDate();
        });

    </script>



</body>

</html>