<?php
// Database credentials
$host = 'localhost';
$db = 'otps_db'; // Your database name
$user = 'root'; // Your database username
$pass = ''; // Your database password
$charset = 'utf8mb4';

// Create a new PDO instance
try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// Get the IDs from POST request
$ids = isset($_POST['ids']) ? $_POST['ids'] : [];

// Validate IDs are an array and contain only integers
$ids = array_filter($ids, function ($value) {
    return is_numeric($value);
});

if (count($ids) > 0) {
    // Convert each ID to an integer (for security reasons)
    $ids = array_map('intval', $ids);

    // Create a string of placeholders for the query
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    try {
        $stmt = $pdo->prepare("DELETE FROM anecdotal_records WHERE id IN ($placeholders)");
        $stmt->execute($ids);

        if ($stmt->rowCount() > 0) {
            // If deletion was successful
            echo json_encode(['success' => true, 'message' => 'Users deleted successfully.']);
        } else {
            // If no rows are affected
            echo json_encode(['success' => false, 'message' => 'No users found with the specified IDs.']);
        }
    } catch (\PDOException $e) {
        // Handle SQL errors or issues with execution
        error_log("Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to delete users.']);
    }
} else {
    // If the IDs array is empty or not set
    echo json_encode(['success' => false, 'message' => 'Invalid request. No IDs provided.']);
}
