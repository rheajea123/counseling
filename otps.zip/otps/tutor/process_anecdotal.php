<?php

header('Content-Type: application/json');

$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect the data from the form
    $name_of_students = $_POST['name_of_students'];
    $age = $_POST['age'];
    $year_course = $_POST['year_course'];
    $gender = $_POST['gender'];
    $fname = $_POST['fname'];
    $fatherStatus = $_POST['fatherStatus'];
    $occupation1 = $_POST['occupation1'];
    $mname = $_POST['mname'];
    $motherStatus = $_POST['motherStatus'];
    $occupation2 = $_POST['occupation2'];
    $guardian = $_POST['guardian'];
    $occupation3 = $_POST['occupation3'];
    $paddress = $_POST['paddress'];
    $psaddress = $_POST['psaddress'];
    $cnumber = $_POST['cnumber'];
    $dateTime = $_POST['dateTime'];
    $observedBehavior = $_POST['observedBehavior'];
    $commentsRecommendations = $_POST['commentsRecommendations'];

    // Prepare the SQL statement
    $sql = "INSERT INTO anecdotal_records (name_of_students, age, year_course, gender, fname, fatherStatus, occupation1, mname, motherStatus, occupation2, guardian, occupation3, paddress, psaddress, cnumber, dateTime, observedBehavior, commentsRecommendations) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sissssssssssssisss", $name_of_students, $age, $year_course, $gender, $fname, $fatherStatus, $occupation1, $mname, $motherStatus, $occupation2, $guardian, $occupation3, $paddress, $psaddress, $cnumber, $dateTime, $observedBehavior, $commentsRecommendations);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Record added successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $stmt->error]);
    }
    $stmt->close();
}
$conn->close();
?>