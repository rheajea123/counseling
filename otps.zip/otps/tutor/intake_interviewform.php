<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>

<body>
    <div class="container mt-4" style="background:white;">
        <h1 style="text-align: center">GUIDANCE OFFICE</h1>
        <p style="text-align: center">Intake Interview Form</p>
        <form id="intakeInterview" class="row g-4" method="post" action="intakeinterview.php">
            <div class="col-md-6">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" required />
            </div>
            <div class="col-md-6">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" required />
            </div>
            <div class="col-md-6">
                <label for="year_course">Year & Course:</label>
                <input type="text" class="form-control" id="year_course" name="year_course" required />
            </div>
            <div class="col-md-6">
                <label>Interview Type:</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="interview_type" id="f2f" value="F2F" required />
                    <label class="form-check-label" for="f2f">F2F</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="interview_type" id="virtual" value="Virtual" />
                    <label class="form-check-label" for="virtual">Virtual</label>
                </div>
            </div>
            <label> Intro Statement:</label>
            <p> Good Morning/Afternoon. You are here to undergo the intake interview service of the Guidance Office.
                This
                interview aims to know you better and understand the role of the school and the office in your
                college life
                experience. Are you ready? Please answer the questions honestly. Thank you.</p>
            <div class="container mt-3">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <div class="readonly-div">
                            Guide Questions
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="readonly-div">
                            Answers
                        </div>
                    </div>
                </div>
            </div>

            <div class="row no-gutters">
                <div class="col-md-6">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        As a student, what are your expectations of the school?
                    </div>
                </div>
                <div class="col-md-6">
                    <textarea id="expectations_school" name="expectations_school" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        As a student, what are your expectations of your instructors?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <textarea id="expectations_instructors" name="expectations_instructors" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        As a student, what are your expectations of your peers?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <textarea id="expectations_peers" name="expectations_peers" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Are you aware of the rules and regulations of the school?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <textarea id="regulations_of_the_school" name="regulations_of_the_school" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <!-- mt-0 and pt-0 are classes to remove top margins and padding -->
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What will happen if you will violate the set school rules?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_rules" name="expectations_rules" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Are you aware that recording audio and video without consent is prohibited by law?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_law" name="expectations_law" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What are your insights about people sharing demeaning post on Social Media?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_social_media" name="expectations_social_media" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What if you argued with your classmates? Will you post something wrong about them? Why?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="something_wrong_about_them" name="something_wrong_about_them" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What will you do if you see a post so demeaning or scandalous and stains the school
                        reputation?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_schools_reputation" name="expectations_schools_reputation" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What are your thoughts about bullying incidences in your classroom? In Social Media?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="incidences_in_your_classroom" name="incidences_in_your_classroom" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Do you have an extended family living situation?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_situation" name="expectations_situation" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Who are the people living in your home?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_home" name="expectations_home" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Describe your relationships with your parents.
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_parents" name="expectations_parents" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Describe your relationship with your siblings.
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id=" expectations_siblings" name=" expectations_siblings" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Describe your relationship with other people living in your home.
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="living_in_your_home" name="living_in_your_home" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Do you parent's set house rules?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="house_rules" name="house_rules" rows="2" class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Can you state those rules?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="state_those_rules" name="state_those_rules" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What consequences do you face if you do not follow the rules?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="consequences_if_you_not_follow_rules" name="consequences_if_you_not_follow_rules"
                        rows="2" class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What are some things you do together as a family?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="together_as_a_family" name="together_as_a_family" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        Where do you spend most of your time?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_time" name="expectations_time" rows="2" class="form-control"
                        required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What is Guidance Office?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="expectations_guidance_office" name="expectations_guidance_office" rows="2"
                        class="form-control" required></textarea>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <div style="overflow-y: auto; background-color: #f8f9fa; color: #495057; border: 1px solid #ced4da; border-radius: 0.25rem; padding: 0.375rem 0.75rem; min-height: 38px;"
                        readonly>
                        What do you think is the role of a Guidance Counselor/Advocate?
                    </div>
                </div>
                <div class="col-md-6 mt-0 pt-0">
                    <textarea id="guidance_counselor_advocate" name="guidance_counselor_advocate" rows="2"
                        class="form-control" required></textarea>
                </div>
            </div>
            <div class="col-md-12 d-flex justify-content-center" style="margin-top: 20px;">
                <!-- Added margin-top here -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $('#intakeInterview').on('submit', function (e) {
            e.preventDefault(); // Prevent default form submission
            var formData = $(this).serialize(); // Serialize the form data

            $.ajax({
                url: 'intakeinterview.php', // URL to server-side script for form submission
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.success) {
                        Swal.fire('Success', response.message, 'success')
                            .then(function () {
                                // Redirect after the Swal alert
                                window.location.href = '';
                            });



                        // Assuming you have an ID returned from the server for the new entry
                        var newRow = '<tr>' +
                            '<td>' + response.id + '</td>' +
                            '<td>' + $('#name').val() + '</td>' +
                            '<td>' + $('#date').val() + '</td>' +
                            '<td>' + $('#year_course').val() + '</td>' +
                            '<td>' + $('#interview_type').val() + '</td>' +
                            '<td>' + $('#expectations_school').val() + '</td>' +
                            '<td>' + $('#expectations_instructors').val() + '</td>' +
                            '<td>' + $('#expectations_peers').val() + '</td>' +
                            '<td>' + $('#regulations_of_the_school').val() + '</td>' +
                            '<td>' + $('#expectations_rules').val() + '</td>' +
                            '<td>' + $('#expectations_law').val() + '</td>' +
                            '<td>' + $('#expectations_social_media').val() + '</td>' +
                            '<td>' + $('#something_wrong_about_them').val() + '</td>' +
                            '<td>' + $('#expectations_schools_reputation').val() + '</td>' +
                            '<td>' + $('#incidences_in_your_classroom').val() + '</td>' +
                            '<td>' + $('#expectations_situation').val() + '</td>' +
                            '<td>' + $('#expectations_home').val() + '</td>' +
                            '<td>' + $('#expectations_parents').val() + '</td>' +
                            '<td>' + $('#expectations_siblings').val() + '</td>' +
                            '<td>' + $('#living_in_your_home').val() + '</td>' +
                            '<td>' + $('#house_rules').val() + '</td>' +
                            '<td>' + $('#state_those_rules').val() + '</td>' +
                            '<td>' + $('#consequences_if_you_not_follow_rules').val() + '</td>' +
                            '<td>' + $('#together_as_a_family').val() + '</td>' +
                            '<td>' + $('#expectations_time').val() + '</td>' +
                            '<td>' + $('#expectations_guidance_office').val() + '</td>' +
                            '<td>' + $('#guidance_counselor_advocate').val() + '</td>' +
                            '<td>' +
                            '<a class="btn btn-primary btn-sm view-user" data-id="' + response.id + '" data-toggle="modal" data-target="#viewModal">View</a>' +
                            '<a class="btn btn-primary btn-sm edit-user" data-id="' + response.id + '" data-toggle="modal" data-target="#editModal">Edit</a>' +
                            '<a class="btn btn-danger btn-sm delete-user" data-id="' + response.id + '">Delete</a>' +
                            '</td>' +
                            '</tr>';

                        $('#students tbody').append(newRow); // Append the new row to the table
                        $('#intakeInterview')[0].reset(); // Reset the form fields
                    } else {
                        Swal.fire('Error', response.message || 'An error occurred', 'error');
                    }
                },
                error: function (xhr, status, error) {
                    console.log('AJAX Error:', xhr, status, error);
                    Swal.fire('Error', 'Submission failed: ' + error, 'error');
                }
            });
        });
    </script>
</body>

</html>