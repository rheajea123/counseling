<?php
header('Content-Type: application/json'); // Set proper content type for JSON response

$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data here
    // Example: $sessionNo = filter_input(INPUT_POST, 'session_no', FILTER_SANITIZE_NUMBER_INT);

    try {
        $stmt = $pdo->prepare("INSERT INTO counseling_sessions (session_no, session_type, date, name, age, year_course, gender, student_description, subjective_complaint, objective_findings, assessment_of_progress, plans_for_next_session, other_important_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $data = [
            $_POST['session_no'] ?? null,
            $_POST['session_type'] ?? null,
            $_POST['date'] ?? null,
            $_POST['name'] ?? null,
            $_POST['age'] ?? null,
            $_POST['year_course'] ?? null,
            $_POST['gender'] ?? null,
            $_POST['student_description'] ?? null,
            $_POST['subjective_complaint'] ?? null,
            $_POST['objective_findings'] ?? null,
            $_POST['assessment_of_progress'] ?? null,
            $_POST['plans_for_next_session'] ?? null,
            $_POST['other_important_notes'] ?? null
        ];

        $stmt->execute($data); // Execute the prepared statement with the data array

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Data submitted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Data submission failed']);
        }
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>