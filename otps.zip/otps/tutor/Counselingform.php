<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>
<style>
    .center-button {
        display: flex;
        justify-content: center;
    }
</style>

<body>
    <div class="container mt-4" style="background:white;">
        <h1 style="text-align: center">GUIDANCE OFFICE</h1>
        <p style="text-align: center">Guidance Counseling Form</p>
        <form id="counselingForm" class="row g-4" method="post" action="submit.php">
            <div class="col-md-4">
                <label for="session_no">Session No.:</label>
                <input type="number" class="form-control" id="session_no" name="session_no" required />
            </div>
            <div class="col-md-4">
                <label>Session Type:</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="session_type" id="f2f" value="F2F" required />
                    <label class="form-check-label" for="f2f">F2F</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="session_type" id="virtual" value="Virtual" />
                    <label class="form-check-label" for="virtual">Virtual</label>
                </div>
            </div>
            <div class="col-md-4">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" required />
            </div>
            <div class="col-md-8">
                <label for="name">Name of Student:</label>
                <input type="text" class="form-control" id="name" name="name" required />
            </div>
            <div class="col-md-4">
                <label for="age">Age:</label>
                <input type="number" class="form-control" id="age" name="age" required />
            </div>
            <div class="col-md-8">
                <label for="year_course">Year & Course:</label>
                <input type="text" class="form-control" id="year_course" name="year_course" required />
            </div>
            <div class="col-md-4">
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" class="form-select" required>
                    <option value="">Choose...</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="col-md-12">
                <label for="student_description">Client/Student Description:</label>
                <textarea id="student_description" name="student_description" rows="4" cols="50" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12">
                <label for="subjective_complaint">Subjective Complaint:</label>
                <textarea id="subjective_complaint" name="subjective_complaint" rows="4" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12">
                <label for="objective_findings">Objective Findings:</label>
                <textarea id="objective_findings" name="objective_findings" rows="4" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12">
                <label for="assessment_of_progress">Assessment of Progress:</label>
                <textarea id="assessment_of_progress" name="assessment_of_progress" rows="4" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12">
                <label for="plans_for_next_session">Plans for Next Session:</label>
                <textarea id="plans_for_next_session" name="plans_for_next_session" rows="4" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12">
                <label for="other_important_notes">Other Important Notes:</label>
                <textarea id="other_important_notes" name="other_important_notes" rows="4" class="form-control"
                    required></textarea>
            </div>
            <div class="col-md-12 d-flex justify-content-center" style="margin-top: 20px;">
                <!-- Added margin-top here -->
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $('#counselingForm').on('submit', function (e) {
            e.preventDefault(); // Prevent default form submission
            var formData = $(this).serialize(); // Serialize the form data

            $.ajax({
                url: 'submit.php', // URL to server-side script for form submission
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.success) {
                        Swal.fire('Success', response.message, 'success')
                            .then(function () {
                                // Redirect after the Swal alert
                                window.location.href = '';
                            });

                        // Assuming you have an ID returned from the server for the new entry
                        var newRow = '<tr>' +
                            '<td>' + response.id + '</td>' +
                            '<td>' + $('#session_no').val() + '</td>' +
                            '<td>' + $('#session_type').val() + '</td>' +
                            '<td>' + $('#date').val() + '</td>' +
                            '<td>' + $('#name').val() + '</td>' +
                            '<td>' + $('#age').val() + '</td>' +
                            '<td>' + $('#year_course').val() + '</td>' +
                            '<td>' + $('#gender').val() + '</td>' +
                            '<td>' + $('#student_description').val() + '</td>' +
                            '<td>' + $('#subjective_complaint').val() + '</td>' +
                            '<td>' + $('#objective_findings').val() + '</td>' +
                            '<td>' + $('#assessment_of_progress').val() + '</td>' +
                            '<td>' + $('#plans_for_next_session').val() + '</td>' +
                            '<td>' + $('#other_important_notes').val() + '</td>' +
                            '<td>' +
                            '<a class="btn btn-primary btn-sm view-user" data-id="' + response.id + '" data-toggle="modal" data-target="#viewModal">View</a>' +
                            '<a class="btn btn-primary btn-sm edit-user" data-id="' + response.id + '" data-toggle="modal" data-target="#editModal">Edit</a>' +
                            '<a class="btn btn-danger btn-sm delete-user" data-id="' + response.id + '">Delete</a>' +
                            '</td>' +
                            '</tr>';

                        $('#students tbody').append(newRow); // Append the new row to the table
                        $('#counselingForm')[0].reset(); // Reset the form fields
                    } else {
                        Swal.fire('Error', response.message || 'An error occurred', 'error');
                    }
                },
                error: function (xhr, status, error) {
                    console.log('AJAX Error:', xhr, status, error);
                    Swal.fire('Error', 'Submission failed: ' + error, 'error');
                }
            });
        });

    </script>
</body>

</html>