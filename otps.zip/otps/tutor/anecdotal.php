</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>

<body>
    <div class="container mt-4" style="background:white;">
        <h1 style="text-align: center">GUIDANCE OFFICE</h1>
        <p style="text-align: center">Intake Interview Form</p>
        <form id="anecdotalForm" class="row g-4">
            <div class="col-md-8">
                <label for="name_of_students" class="form-label">Name of Student:</label>
                <input type="text" class="form-control" id="name_of_students" name="name_of_students" required>
            </div>
            <div class="col-md-4">
                <label for="age" class="form-label">Age:</label>
                <input type="number" class="form-control" id="age" name="age" required>
            </div>
            <div class="col-md-8">
                <label for="year_course" class="form-label">Year & Course:</label>
                <input type="text" class="form-control" id="year_course" name="year_course" required>
            </div>
            <div class="col-md-4">
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" class="form-select" required>
                    <option value="">Choose...</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="col-md-6">
                <label for="fname" class="form-label">Father's name:</label>
                <input type="text" class="form-control" id="fname" name="fname" required>
            </div>
            <div class="col-md-2">
                <label class="form-label"></label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="fatherStatus" id="fatherLiving" value="Living"
                        required>
                    <label class="form-check-label" for="fatherLiving">Living</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="fatherStatus" id="fatherDeceased"
                        value="Deceased">
                    <label class="form-check-label" for="fatherDeceased">Deceased</label>
                </div>
            </div>
            <div class="col-md-4">
                <label for="occupation1" class="form-label">Occupation:</label>
                <input type="text" class="form-control" id="occupation1" name="occupation1" required>
            </div>
            <div class="col-md-6">
                <label for="mname" class="form-label">Mother's name:</label>
                <input type="text" class="form-control" id="mname" name="mname" required>
            </div>
            <div class="col-md-2">
                <label class="form-label"></label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="motherStatus" id="motherLiving" value="Living"
                        required>
                    <label class="form-check-label" for="motherLiving">Living</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="motherStatus" id="motherDeceased"
                        value="Deceased">
                    <label class="form-check-label" for="motherDeceased">Deceased</label>
                </div>
            </div>
            <div class="col-md-4">
                <label for="occupation2" class="form-label">Occupation:</label>
                <input type="text" class="form-control" id="occupation2" name="occupation2" required>
            </div>
            <div class="col-md-8">
                <label for="guardian" class="form-label">Guardian(if not living with parents):</label>
                <input type="text" class="form-control" id="guardian" name="guardian" required>
            </div>
            <div class="col-md-4">
                <label for="occupation3" class="form-label">Occupation:</label>
                <input type="text" class="form-control" id="occupation3" name="occupation3" required>
            </div>
            <div class="col-md-12">
                <label for="paddress" class="form-label">Permanent Address:</label>
                <input type="text" class="form-control" id="paddress" name="paddress" required>
            </div>
            <div class="col-md-12">
                <label for="psaddress" class="form-label">Present Address:</label>
                <input type="text" class="form-control" id="psaddress" name="psaddress" required>
            </div>
            <div class="col-md-12">
                <label for="cnumber" class="form-label">Contact Number:</label>
                <input type="number" class="form-control" id="cnumber" name="cnumber" required>
            </div>
            <div class="col-12">
                <div class="row g-2 mb-3">
                    <div class="col-md-4">
                        <label for="dateTime">Date & Time/Place of Observations</label>
                        <textarea id="dateTime" name="dateTime" rows="4" class="form-control form-control-tall"
                            required></textarea>
                    </div>
                    <div class="col-md-4">
                        <label for="observedBehavior">Observed Behavior<i>(That Need to be Recorded)</i></label>
                        <textarea id="observedBehavior" name="observedBehavior" rows="4"
                            class="form-control form-control-tall" required></textarea>
                    </div>
                    <div class="col-md-4">
                        <label for="commentsRecommendations">Comments/Recommendations</label>
                        <textarea id="commentsRecommendations" name="commentsRecommendations" rows="4"
                            class="form-control form-control-tall" required></textarea>
                    </div>
                    <div class="col-md-12 d-flex justify-content-center" style="margin-top: 20px;">
                        <!-- Added margin-top here -->
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.getElementById('anecdotalForm').addEventListener('submit', function (e) {
            e.preventDefault();

            var allFilled = true;
            document.querySelectorAll('#anecdotalForm [required]').forEach(function (el) {
                if (!el.value.trim()) {
                    console.log("Empty field found", el); // Debugging line
                    allFilled = false;
                }
            });

            console.log("All filled:", allFilled); // Debugging line

            if (!allFilled) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Incomplete Form',
                    text: 'Please fill up the form completely.'
                });
                return; // Stop the function if the form is not filled completely
            }

            var formData = new FormData(this);

            axios.post('process_anecdotal.php', formData)
                .then(function (response) {
                    if (response.data.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: response.data.message,
                            icon: 'success'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'http://localhost/otps/tutor/?page=anecdotal'; // Redirect to home.php
                            }
                        });
                    } else {
                        Swal.fire('Error', response.data.message, 'error');
                    }
                })
                .catch(function (error) {
                    Swal.fire('Error', 'An error occurred during submission', 'error');
                });
        });
    </script>
</body>

</html>