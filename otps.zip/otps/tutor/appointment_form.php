<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Guidance Counseling Appointment Form</title>
	<!-- Include DataTables CSS -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
	<!-- Include SweetAlert2 for alerts -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>
	<div class="container mt-4" style="background:white;">
		<h1 style="text-align: center">GUIDANCE OFFICE</h1>
		<p style="text-align: center">Guidance Counseling Appointment Form</p>
		<form id="appointmentForm" class="row g-4" method="post" action="submit.php">
			<div class="col-md-6">
				<label for="fullname">Full Name:</label>
				<input type="text" class="form-control" id="fullname" name="fullname" required />
			</div>
			<div class="col-md-6">
				<label for="age">Age:</label>
				<input type="number" class="form-control" id="age" name="age" required />
			</div>
			<div class="col-md-6">
				<label for="course">Program:</label>
				<input type="text" class="form-control" id="course" name="course" required />
			</div>
			<div class="col-md-6">
				<label for="gender">Gender:</label>
				<select id="gender" name="gender" class="form-select" required>
					<option value="">Choose...</option>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
				</select>
			</div>
			<div class="col-md-6">
				<label for="appointment_date">Appointment Date:</label>
				<input type="date" class="form-control" id="appointment_date" name="appointment_date" required />
			</div>
			<div class="col-md-6">
				<label for="appointment_time">Appointment Time:</label>
				<input type="time" class="form-control" id="appointment_time" name="appointment_time" required />
			</div>
			<div class="col-md-6">
				<label for="reason_for_referral">Reason for Referral:</label>
				<input type="text" class="form-control" id="reason_for_referral" name="reason_for_referral" required />
			</div>
			<div class="col-md-12">
				<label for="reason_concerns">State Reason/Concerns:</label>
				<textarea id="reason_concerns" name="reason_concerns" rows="4" class="form-control" required></textarea>
			</div>
			<div class="col-md-12 d-flex justify-content-center" style="margin-top: 20px;">
				<!-- Added margin-top here -->
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</form>
	</div>

	<!-- Include jQuery before other scripts -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<!-- Include jQuery UI -->
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
	<!-- Include DataTables JS -->
	<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
	<!-- Include SweetAlert2 for alerts -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<!-- Include Axios for AJAX requests -->
	<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

	<script>
		$(document).ready(function () {
			$('#appointmentForm').on('submit', function (e) {
				e.preventDefault(); // Prevent default form submission
				var formData = $(this).serialize(); // Serialize the form data

				$.ajax({
					url: 'appointment.php', // URL to server-side script for form submission
					type: 'POST',
					data: formData,
					success: function (response) {
						console.log(response); // Debugging: log the response from the server
						if (response.success) {
							Swal.fire('Success', response.message, 'success')
								.then(function () {
									// Refresh or redirect after successful submission
									window.location.reload();
								});
						} else {
							Swal.fire('Error', response.message, 'error');
						}
					},
					error: function (xhr, status, error) {
						console.error(xhr.responseText); // Debugging: log the error response
						Swal.fire('Error', 'Submission failed: ' + error, 'error');
					}
				});
			});
		});
	</script>
</body>

</html>