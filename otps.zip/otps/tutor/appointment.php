<?php
header('Content-Type: application/json'); // Set proper content type for JSON response

$host = 'localhost';
$db = 'otps_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data here

    try {
        $stmt = $pdo->prepare("INSERT INTO appointments (fullname, age, course, gender, appointment_date, appointment_time, reason_for_referral, reason_concerns) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        $data = [
            $_POST['fullname'] ?? null,
            $_POST['age'] ?? null,
            $_POST['course'] ?? null,
            $_POST['gender'] ?? null,
            $_POST['appointment_date'] ?? null,
            $_POST['appointment_time'] ?? null,
            $_POST['reason_for_referral'] ?? null,
            $_POST['reason_concerns'] ?? null
        ];

        $stmt->execute($data); // Execute the prepared statement with the data array

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Data submitted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Data submission failed']);
        }
    } catch (\PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>